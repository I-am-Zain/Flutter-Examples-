# Flutter Gooey slideout menu using Flutter

This is the source code for the Tutorial that shows how to build a a Slideout menu in Flare. Then using [SmartFlare](https://pub.dartlang.org/packages/smart_flare) to add some interactive functionality to it.