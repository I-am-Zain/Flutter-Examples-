enum ConnectivityStatus {
  WiFi,
  Cellular,
  Offline
}